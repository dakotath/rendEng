var searchData=
[
  ['corelib_20documentation_0',['CoreLib Documentation',['../index.html',1,'']]]
];
